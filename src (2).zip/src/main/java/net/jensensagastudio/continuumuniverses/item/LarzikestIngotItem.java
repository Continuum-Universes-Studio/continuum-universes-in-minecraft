package net.jensensagastudio.continuumuniverses.item;

import net.minecraft.world.item.Item;

public class LarzikestIngotItem extends Item {
	public LarzikestIngotItem(Item.Properties properties) {
		super(properties);
	}
}