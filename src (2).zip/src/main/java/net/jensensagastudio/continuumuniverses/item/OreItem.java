package net.jensensagastudio.continuumuniverses.item;

import net.minecraft.world.item.Item;

public class OreItem extends Item {
    public OreItem(Properties properties) {
        super(properties);
    }
}
