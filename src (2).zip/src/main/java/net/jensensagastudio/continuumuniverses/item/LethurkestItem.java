package net.jensensagastudio.continuumuniverses.item;

import net.minecraft.world.item.Item;

public class LethurkestItem extends Item {
	public LethurkestItem(Item.Properties properties) {
		super(properties);
	}
}