package net.jensensagastudio.continuumuniverses.item;

import net.minecraft.world.item.Item;

public class KormikestDustItem extends Item {
	public KormikestDustItem(Properties properties) {
		super(properties);
	}
}