package net.jensensagastudio.continuumuniverses.item;

import net.minecraft.world.item.Item;

public class VarkestIngotItem extends Item {
	public VarkestIngotItem(Item.Properties properties) {
		super(properties);
	}
}