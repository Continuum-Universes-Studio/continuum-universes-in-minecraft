package net.jensensagastudio.continuumuniverses.item;

import net.minecraft.world.item.Item;

public class StarSteelIngotItem extends Item {
    public StarSteelIngotItem(Item.Properties properties) {
        super(properties);
    }
}
