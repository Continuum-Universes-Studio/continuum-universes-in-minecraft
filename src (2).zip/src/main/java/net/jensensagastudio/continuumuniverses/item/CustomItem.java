package net.jensensagastudio.continuumuniverses.item;

import net.minecraft.world.item.Item;

public class CustomItem extends Item {
    public CustomItem(Properties properties) {
        super(properties);
    }
}


