package net.jensensagastudio.continuumuniverses.world.dimension;

import net.jensensagastudio.continuumuniverses.ContinuumUniverses;
import net.minecraft.data.worldgen.DimensionTypes;
import net.minecraft.resources.Identifier;
import net.minecraft.world.attribute.EnvironmentAttribute;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.minecraft.world.level.dimension.DimensionType;
public final class UvlaDimension extends DimensionTypes {

	// IMPORTANT: this must match your *dimension type* id (the thing used by your dimension JSON "type")
	public static final Identifier UVLA_DIMENSION_TYPE =
			Identifier.fromNamespaceAndPath(ContinuumUniverses.MODID, "uvla");
}
